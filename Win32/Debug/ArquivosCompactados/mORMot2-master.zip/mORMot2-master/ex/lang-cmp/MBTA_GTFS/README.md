
### lang-cmp

Please download and unzip here the CSV reference values
from https://cdn.mbta.com/MBTA_GTFS.zip

At least `trips.txt` and `stop_times.txt` should be available.
