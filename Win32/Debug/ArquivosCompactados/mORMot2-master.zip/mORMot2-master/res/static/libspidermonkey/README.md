# mORMot Static Compilation Notice

**WARNING: First DRAFT version, directly copied from mORMot 1.18 Synode folder - files have NOT been yet adapted to mORMot 2, so the Synode is to be used instead !**

# SpiderMonkey library 

## SpiderMonkey 52 (recommended)

Precompiled binary can be downloaded here:

  - Win x32: https://unitybase.info/media/files/synmozjs52x32dlls.zip
  - Win x64: https://unitybase.info/media/files/synmozjs52x64dlls.zip
  - Linux x64: https://unitybase.info/media/files/libsynmozjs52.zip

Or compiled from sources as described [in  instructions inside mozjs folder](/mozjs)

## SpiderMonkey 45 (not supported)

Precompiled binary can be downloaded here:

 - x32: https://unitybase.info/downloads/mozjs-45.zip
 - x64: https://unitybase.info/downloads/mozjs-45-x64.zip
