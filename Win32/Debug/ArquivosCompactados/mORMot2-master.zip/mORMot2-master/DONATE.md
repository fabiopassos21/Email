# How to help?

![Happy mORMot](doc/happymormot.png)

## Adopt a mORMot !

The first mean of help for any Open Source project is to use and contribute to it.

Do not be shy: a lot of code within our projects has been committed by external contributors. Let's make this great Open Source adventure continue!

If you make any profit by using our components, you are encouraged to give something back to us. It will help making better libraries, and introducing new features.

## One-Time Donation

First mean is via PayPal donation:

[Donate via PayPal](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=83RD8UYWHNR3W&lc=US&item_name=Synopse%20OpenSource%20libraries&item_number=WebDonation&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donate_LG%2egif%3aNonHosted)

## Monthly Sponsorship

You can of course consider becoming a GitHub sponsor:

https://github.com/sponsors/synopse

## The mORMot Thanks You!

Major contributors will of course be named within the project source code!

This is a common work!