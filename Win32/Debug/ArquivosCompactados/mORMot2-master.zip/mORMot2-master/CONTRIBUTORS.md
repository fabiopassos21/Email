## Copyright Holder

According to [the project licence terms](LICENCE.md), Synopse Informatique, and Arnaud Bouchez as the main Author of the Open Source *mORMot* framework, are the Copyright Holders.

But nothing would have been possible without a big number of Contributors, who provided fixes or enhancements.

## Contributors

A huge *THANK YOU* is worth giving to all of the contributors of our Open Source *mORMot* framework, since its initial release more than 10 years ago!

- Alan Chate
- Ali Erturk Turker
- Alexander (sha)
- Alexander (volax)
- AlexPirate
- Alfred Glaenzer (alf)
- Andre Heider (dhewg)
- Andreas Leroux (andreaslrx)
- ASiwon
- Aweste
- Bas Schouten
- BigStar
- BugsDigger
- Cheemeng
- CoMPi
- Damien (ddemars)
- Darian Miller
- Daniel Kuettner
- David Mead (MDW)
- Delphinium (louisyeow)
- DigDiver
- Dominikcz
- EgorovAlex
- Emanuele (lele9)
- Eric Grange
- Esmond
- Esteban Martin (EMartin)
- Eugene Ilyin
- Eva Freimann (EVaF)
- Evan Blaudy (eblaudy)
- FeelAirSlow
- F-Vicente
- Goran Despalatovic (gigo)
- Hubert Touvet
- Javierus TK
- Jean-Baptiste Roussia (jbroussia)
- Joe (jokusoft)
- Johan Bontes
- Jordi Tudela
- Kevin Chen
- Lagodny
- Leon Oosthuizen
- Macc2010
- Maciej Izak (hnb)
- Marcos Douglas B. Santos (mdbs99)
- Mario Moretti
- Marius Maximus (mariuszekpl)
- Martin Doyle
- Martin Eckes
- Martin Suer
- Mateus Abade
- Matkov
- Maxim Masiutin
- Mazinsw
- MChaos
- Miab3
- Michael (EgonHugeist)
- Michalis Kamburelis
- MilesYou
- Mingda
- Mr Yang (ysair)
- Nicolas Marchand (MC)
- Nortg
- Nzsolt
- OkobaPatino
- Oleg Tretyakov
- Ondrej (reddwarf)
- Pavel Mashlyakovskii (mpv)
- Pierre le Riche
- RalfS
- Richard6688
- Rik (rvk)
- Sabbiolina
- Sanyin
- Sinisa (sinisav)
- Sllimr7139
- SSoftPro
- Stefan (itSDS)
- Svetozar Belic (transmogrifix)
- Ti Hory (tihorygit)
- Tino Teuber
- TTomas (tom)
- Thomas (tbo)
- Uian2000
- Vaclav
- Vadim Orel
- Willo vd Merwe
- Win2014
- Wloochacz
- Wolfgang Ehrhardt
- Yoanq
- Ysair
- Zed

Don't be shy, contribute and make a pull request, and you will be in this Hall of Fame!

:)
