# mORMot Framework IDE Setup Files

## Folder Content

This folder contains some packages and setup tools for the Delphi and Lazarus IDE.

## Sub-Folders

The source code tree is split into the following sub-folders:

- [`lazarus`](lazarus) packages for Lazarus/FPC.
