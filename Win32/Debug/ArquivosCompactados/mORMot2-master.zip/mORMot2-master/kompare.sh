#!/bin/bash

meld ~/dev/github/mORMot2 ~/dev/lib2